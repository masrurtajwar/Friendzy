module.exports = { 
    home: require("./home")
}